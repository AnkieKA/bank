package com.example.demoApp.controller;

import java.sql.Connection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoApp.model.Customer;
import com.example.demoApp.model.Transaction;
import com.example.demoApp.repository.TransactionRepository;

import util.DButil;

@CrossOrigin(origins= "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class TransactionController {
	Customer cust=new Customer("1");
	//int amt=100;
	Integer amt=new Integer(100);
	@Autowired
	private TransactionRepository transactionRepository;
	
	
	Connection connection = DButil.getConnection();

	public TransactionController() {
		connection = DButil.getConnection();
		System.out.println("connection" + connection);
	}

	
	@GetMapping("/transaction")
	public List<Transaction> getAllTransactions()
	{
		System.out.println("Transaction created");
		return transactionRepository.findAll();
		
	}
	
	@GetMapping("/transfer/{customer_username}/{customer_password}/{amt}/{reciever_ac_no}")
	public int transfer(String customer_username,String customer_password,Integer amt,Long customer_ac_no) { 
		System.out.println("hello");
		System.out.println(customer_username);
	 return cust.transfer(customer_username,customer_password,amt,customer_ac_no);
	
	}
	

}
