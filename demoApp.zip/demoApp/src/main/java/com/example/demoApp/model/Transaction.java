package com.example.demoApp.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="transaction")
public class Transaction {
	
	private int trans_id;
	private Date trans_date;
	private long credited_amt;
	private long debited_amt;
	    @OneToOne(cascade = CascadeType.ALL)
	    @JoinColumn(unique = true)
	private long customer_ac_no;
	
	public Transaction(int trans_id, Date trans_date, long credited_amt, long debited_amt, long customer_ac_no) {
		super();
		this.trans_id = trans_id;
		this.trans_date = trans_date;
		this.credited_amt = credited_amt;
		this.debited_amt = debited_amt;
		this.customer_ac_no = customer_ac_no;
	}

	
	public Transaction() {
		super();
	}

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getTrans_id() {
		return trans_id;
	}

	public void setTrans_id(int trans_id) {
		this.trans_id = trans_id;
	}

	@Column(name="trans_date", nullable=false)
	public Date getTrans_date() {
		return trans_date;
	}

	public void setTrans_date(Date trans_date) {
		this.trans_date = trans_date;
	}

	@Column(name="credited_amt", nullable=true)
	public long getCredited_amt() {
		return credited_amt;
	}

	public void setCredited_amt(long credited_amt) {
		this.credited_amt = credited_amt;
	}

	@Column(name="debited_amt", nullable=true)
	public long getDebited_amt() {
		return debited_amt;
	}

	public void setDebited_amt(long debited_amt) {
		this.debited_amt = debited_amt;
	}

	@Column(name="customer_ac_no", nullable=false)
	public long getCustomer_ac_no() {
		return customer_ac_no;
	}

	public void setCustomer_ac_no(long customer_ac_no) {
		this.customer_ac_no = customer_ac_no;
	}

	@Override
	public String toString() {
		return "Transaction [trans_id=" + trans_id + ", trans_date=" + trans_date + ", credited_amt=" + credited_amt
				+ ", debited_amt=" + debited_amt + ", customer_ac_no=" + customer_ac_no + "]";
	}
	
	
	

}
