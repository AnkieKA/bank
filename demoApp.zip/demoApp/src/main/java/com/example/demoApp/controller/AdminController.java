package com.example.demoApp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoApp.exception.ResourceNotFoundException;
import com.example.demoApp.model.Admin;
import com.example.demoApp.repository.AdminRepository;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class AdminController {
	@Autowired
	private AdminRepository adminRepository;
	
	@GetMapping("/admin")
	public List<Admin> getAllEmployees(){
		return adminRepository.findAll();
	}
	
	@GetMapping("/admin/{id}")
	public ResponseEntity<Admin> getAdminById(@PathVariable(value="id") Long adminId)
	throws ResourceNotFoundException{
		Admin admin=adminRepository.findById(adminId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id::" +adminId));
				return ResponseEntity.ok().body(admin);
	}
	
	@PostMapping("/admin")
	public Admin createAdmin(@Valid @RequestBody Admin admin)
	{
		return adminRepository.save(admin);
	}
	
	@DeleteMapping("/admin/{id}")
	public Map<String, Boolean> deleteAdmin(@PathVariable(value="id") Long adminId) 
			throws ResourceNotFoundException{
				Admin admin = adminRepository.findById(adminId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: "+adminId));
				
				adminRepository.delete(admin);
				Map<String,Boolean> response = new HashMap<>();
				response.put("deleted", Boolean.TRUE);
				return response;
	}
	
	@PutMapping("/admin/{id}")
	public ResponseEntity<Admin> updateEmployee(@PathVariable(value = "id") Long adminId,
			@Valid @RequestBody Admin adminDetails) throws ResourceNotFoundException{
		Admin admin = adminRepository.findById(adminId)
		.orElseThrow(()->new ResourceNotFoundException("Employee not found for this id :: "+adminId));
	admin.setAdmin_id(adminDetails.getAdmin_id());
	admin.setAdmin_name(adminDetails.getAdmin_name());
	admin.setAdmin_password(adminDetails.getAdmin_password());
	admin.setAdmin_role(adminDetails.getAdmin_role());
	admin.setAdmin_username(adminDetails.getAdmin_username());
	
		final Admin updatedAdmin = adminRepository.save(admin);
		return ResponseEntity.ok(updatedAdmin);
	}
	
	

}
