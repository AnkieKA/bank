package com.example.demoApp.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "accounts")
public class Accounts {
	@Id
	private String account_id;
	private String account_type;
	private int balance;
	private String description;
	
	public Accounts() {
		super();
	}

	public Accounts(String account_id, String account_type, int balance, String description) {
		super();
		this.account_id = account_id;
		this.account_type = account_type;
		this.balance = balance;
		this.description = description;
	}

	@Column(name = "account_id",nullable = false)
	public String getAccount_id() {
		return account_id;
	}

	public void setAccount_id(String account_id) {
		this.account_id = account_id;
	}
	

	@Column(name = "account_type", unique = true)
	public String getAccount_type() {
		return account_type;
	}

	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}

	@Column(name = "balance",nullable = false)
	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	@Column(name = "description")
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Accounts [account_id=" + account_id + ", account_type=" + account_type + ", balance=" + balance
				+ ", description=" + description + "]";
	}
	
	
	
	
	
	
}
