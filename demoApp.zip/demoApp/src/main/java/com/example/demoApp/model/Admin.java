package com.example.demoApp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admin")

public class Admin
{
	
	private String admin_id;
	private String admin_name;
	private String admin_role;
	private String admin_username;
	private String admin_password;
	

	@Override
	public String toString() {
		return "Admin [admin_id=" + admin_id + ", admin_name=" + admin_name + ", admin_role=" + admin_role
				+ ", admin_username=" + admin_username + ", admin_password=" + admin_password + "]";
	}
	/*@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	@Column(name="first_name", nullable = false)
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	@Column(name="last_name", nullable = false)
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	@Column(name="email_address", nullable = false)
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Employee(String firstName, String lastName, String emailId) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
	}
	public Employee() {
		
	}*/


	


	public Admin(String admin_id, String admin_name, String admin_role, String admin_username, String admin_password) {
		super();
		this.admin_id = admin_id;
		this.admin_name = admin_name;
		this.admin_role = admin_role;
		this.admin_username = admin_username;
		this.admin_password = admin_password;
	}
	public Admin() {
		super();
	}





	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public String getAdmin_id() {
		return admin_id;
	}
	public void setAdmin_id(String admin_id) {
		this.admin_id = admin_id;
	}

	@Column(name="admin_name", nullable = false)
	public String getAdmin_name() {
		return admin_name;
	}


	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}

	@Column(name="admin_role", nullable = false)
	public String getAdmin_role() {
		return admin_role;
	}


	public void setAdmin_role(String admin_role) {
		this.admin_role = admin_role;
	}

	@Column(name="admin_username", nullable = false)
	public String getAdmin_username() {
		return admin_username;
	}


	public void setAdmin_username(String admin_username) {
		this.admin_username = admin_username;
	}

	@Column(name="admin_password", nullable = false)
	public String getAdmin_password() {
		return admin_password;
	}


	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}
	
}
