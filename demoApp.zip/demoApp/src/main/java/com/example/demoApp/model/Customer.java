package com.example.demoApp.model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;


import util.DButil;

@Entity
@Table(name="customer")
public class Customer {
	private String customer_id;
	 
	@OneToMany(mappedBy = "customer_ac_no")
	private  long customer_ac_no;
	private String customer_name;
	private Date customer_dob;
	private String customer_email;
	private  long customer_phone;
	private  long customer_aadhar;
	private  String customer_pan;
	private  String customer_username;
	private  String customer_password;
	private  String customer_loan;
	private  String customer_branch_ifsc;
	private  String customer_ac_id;
	Connection connection = null;
	private static List<Loan> loans;
	
	{
		connection = DButil.getConnection();
		System.out.println(connection);
	}

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	
	@Column(name="customer_ac_no", nullable=false)
	public long getCustomer_ac_no() {
		return customer_ac_no;
	}
	public void setCustomer_ac_no(long customer_ac_no) {
		this.customer_ac_no = customer_ac_no;
	}
	@Column(name="customer_name", nullable=false)
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	
	@Column(name="customer_dob", nullable=false)
	public Date getCustomer_dob() {
		return customer_dob;
	}
	public void setCustomer_dob(Date customer_dob) {
		this.customer_dob = customer_dob;
	}
	
	@Column(name="customer_email", nullable=false)
	public String getCustomer_email() {
		return customer_email;
	}
	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}
	
	@Column(name="customer_phone", nullable=false)
	public long getCustomer_phone() {
		return customer_phone;
	}
	public void setCustomer_phone(long customer_phone) {
		this.customer_phone = customer_phone;
	}
	
	@Column(name="customer_aadhar", nullable=false)
	public long getCustomer_aadhar() {
		return customer_aadhar;
	}
	public void setCustomer_aadhar(long customer_aadhar) {
		this.customer_aadhar = customer_aadhar;
	}
	
	@Column(name="customer_pan", nullable=false)
	public String getCustomer_pan() {
		return customer_pan;
	}
	public void setCustomer_pan(String customer_pan) {
		this.customer_pan = customer_pan;
	}
	
	@Column(name="customer_username", nullable=false)
	public String getCustomer_username() {
		return customer_username;
	}
	public void setCustomer_username(String customer_username) {
		this.customer_username = customer_username;
	}
	
	@Column(name="customer_password", nullable=false)
	public String getCustomer_password() {
		return customer_password;
	}
	public void setCustomer_password(String customer_password) {
		this.customer_password = customer_password;
	}
	
	@Column(name="customer_loan", nullable=false)
	public String getCustomer_loan() {
		return customer_loan;
	}
	public void setCustomer_loan(String customer_loan) {
		this.customer_loan = customer_loan;
	}
	
	public Customer() {
		super();
	}
	@Column(name="customer_branch_ifsc", nullable=false)
	public String getCustomer_branch_ifsc() {
		return customer_branch_ifsc;
	}
	public void setCustomer_branch_ifsc(String customer_branch_ifsc) {
		this.customer_branch_ifsc = customer_branch_ifsc;
	}
	
	@Column(name="customer_ac_id", nullable=false)
	public String getCustomer_ac_id() {
		return customer_ac_id;
	}
	public void setCustomer_ac_id(String customer_ac_id) {
		this.customer_ac_id = customer_ac_id;
	}
	public Customer(String customer_id, long customer_ac_no, String customer_name, Date customer_dob,
			String customer_email, long customer_phone, long customer_aadhar, String customer_pan,
			String customer_username, String customer_password, String customer_loan, String customer_branch_ifsc,
			String customer_ac_id) {
		super();
		this.customer_id = customer_id;
		this.customer_ac_no = customer_ac_no;
		this.customer_name = customer_name;
		this.customer_dob = customer_dob;
		this.customer_email = customer_email;
		this.customer_phone = customer_phone;
		this.customer_aadhar = customer_aadhar;
		this.customer_pan = customer_pan;
		this.customer_username = customer_username;
		this.customer_password = customer_password;
		this.customer_loan = customer_loan;
		this.customer_branch_ifsc = customer_branch_ifsc;
		this.customer_ac_id = customer_ac_id;
	}
	

	public Customer(String customer_username) {this.customer_username = customer_username; }

	public int transfer(String un,String pass,int amt,long customer_ac_no2)
	{
		try
		{
		
		String query="select balance from customer where customer_username='"+un+"' and customer_password='"+pass+"'";
		Statement st=(Statement) connection.createStatement();
		ResultSet rs=st.executeQuery(query);
		rs.next();
		int balance=rs.getInt(1);		
		int bal=balance-amt;
		
		System.out.println("testttttttttttt");
		
		
		String query1="update customer set balance="+bal+" where customer_username='"+un+"'";
		Statement st1=(Statement) connection.createStatement();
		st1.executeUpdate(query1);
		
		String query3="select balance from customer where customer_ac_no="+customer_ac_no2+"";
		Statement st3=(Statement) connection.createStatement();
		ResultSet rs3=st.executeQuery(query3);
		rs3.next();
		int balance1=rs3.getInt(1);		
		int bal1=balance1+amt;
		System.out.println(bal1);

		String query2="update customer set balance="+bal1+" where customer_ac_no="+customer_ac_no2+"";
		Statement st2=(Statement) connection.createStatement();
		st.executeUpdate(query2);
		//System.out.println("Balance="+rs.getInt("balance"));
		System.out.println("Successfully tranferred");
		
		//Transaction table update
				
				String query4="select customer_ac_no from customer where customer_username='"+un+"' and customer_password='"+pass+"'";
				Statement st4=(Statement) connection.createStatement();
				ResultSet rs4=((java.sql.Statement) st4).executeQuery(query4);
				rs4.next();
				int accno=rs4.getInt("customer_ac_no");
				
				//credit transaction
				String query5="select max(tid) from transaction";
				Statement st5=connection.createStatement();
				ResultSet rs5=st5.executeQuery(query5);
				int tempId;
				rs5.next();
				tempId=rs5.getInt(1);
				int tid=tempId+1;
				//date
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
				   LocalDateTime now = LocalDateTime.now();  
				  String trans_date=dtf.format(now);  

				  System.out.println("selected accno");
				String query6="insert into transaction values("+tid+",'"+trans_date+"',"+amt+","+0+","+accno+")"; 
				Statement st6=(Statement) connection.createStatement();
				st6.executeUpdate(query6);
				
				//Debit transaction table
				String query7="select max(tid) from transaction";
				Statement st7=connection.createStatement();
				ResultSet rs7=st7.executeQuery(query7);
				int tempId1;
				rs7.next();
				tempId1=rs7.getInt(1);
				int tid1=tempId1+1;
				//date
				DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
				 LocalDateTime now1 = LocalDateTime.now();  
				 String trans_date1=dtf1.format(now1);  

				
				String query8="insert into transaction values("+tid1+",'"+trans_date+"',"+0+","+amt+","+customer_ac_no2+")"; 
				Statement st8=(Statement) connection.createStatement();
				st8.executeUpdate(query8);
				
				System.out.println("transaction update");
				
		
		}
	   
		
		catch(Exception e)
		{
			System.out.println(e);
		}
		return 1;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public String toString() {
		return "Customer [customer_id=" + customer_id + ", customer_ac_no=" + customer_ac_no + ", customer_name="
				+ customer_name + ", customer_dob=" + customer_dob + ", customer_email=" + customer_email
				+ ", customer_phone=" + customer_phone + ", customer_aadhar=" + customer_aadhar + ", customer_pan="
				+ customer_pan + ", customer_username=" + customer_username + ", customer_password=" + customer_password
				+ ", customer_loan=" + customer_loan + ", customer_branch_ifsc=" + customer_branch_ifsc
				+ ", customer_ac_id=" + customer_ac_id + "]";
	}
	
	
	

}
