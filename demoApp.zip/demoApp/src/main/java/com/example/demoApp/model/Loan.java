package com.example.demoApp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "loan")
public class Loan {
	
	private String loan_id;//primary key
	private String loan_type;
	private String loan_eligibility;
	private float loan_roi;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public String getLoan_id() {
		return loan_id;
	}
	public void setLoan_id(String loan_id) {
		this.loan_id = loan_id;
	}
	
	@Column(name="loan_type", nullable = false)
	public String getLoan_type() {
		return loan_type;
	}
	public void setLoan_type(String loan_type) {
		this.loan_type = loan_type;
	}
	
	@Column(name="loan_eligibility", nullable = false)
	public String getLoan_eligibility() {
		return loan_eligibility;
	}
	public void setLoan_eligibility(String loan_eligibility) {
		this.loan_eligibility = loan_eligibility;
	}
	
	@Column(name="loan_roi", nullable = false)
	public float getLoan_roi() {
		return loan_roi;
	}
	public void setLoan_roi(float loan_roi) {
		this.loan_roi = loan_roi;
	}
	public Loan(String loan_id, String loan_type, String loan_eligibility, float loan_roi) {
		super();
		this.loan_id = loan_id;
		this.loan_type = loan_type;
		this.loan_eligibility = loan_eligibility;
		this.loan_roi = loan_roi;
	}
	@Override
	public String toString() {
		return "Loan [loan_id=" + loan_id + ", loan_type=" + loan_type + ", loan_eligibility=" + loan_eligibility
				+ ", loan_roi=" + loan_roi + "]";
	}
	public Loan() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
