package com.example.demoApp.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demoApp.model.Accounts;

public interface AccountsRepository extends JpaRepository<Accounts, Long>  {

}
